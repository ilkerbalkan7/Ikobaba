﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tournament_Bracket.Lib.Views
{
    /// <summary>
    /// Interaction logic for CreateTournamentView.xaml
    /// </summary>
    /// 
    public partial class CreateTournamentView : UserControl
    {
       

        public CreateTournamentView()
        {
            InitializeComponent();

        }
        private void Button_Click(object sender, EventArgs e)
        {
            if (CreatePlayer.Text.Length == 0)
            {
                EnableAddPlayer.Visibility = Visibility.Visible;

            }
            else if (CreatePlayer.Text.Length > 0)
            {
                EnableAddPlayer.IsEnabled = true;
                PlayerList.Items.Add(CreatePlayer.Text);
                CreatePlayer.Clear();
            }
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {

            this.CreateTournament.Text += "CodeNight Tournament";
            {

            }
            if (CreateTournament.Text == "CodeNight Tournament")
            {
                EnableButton.IsEnabled = false;
            }
            else
            {
                EnableButton.IsEnabled = true;
            }

        }


        private void RemoveTournament_Click(object sender, RoutedEventArgs e)
        {
            if (CreateTournament.Text != null)
            {
                CreateTournament.Clear();
                EnableButton.IsEnabled = true;
            }

            else
            {
                MessageBox.Show("Please type into the textbox.");
                EnableButton.IsEnabled = true;
            }
        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            if (PlayerList.SelectedIndex > -1)
                PlayerList.Items.RemoveAt(PlayerList.SelectedIndex);
            else
            {
                MessageBox.Show("Select an item from listbox.");
            }

        }
        private void PreviousPage_ButtonClick(object sender, RoutedEventArgs e)
        {
            MainWindow win = new MainWindow();
            win.Show();

        }

        private void QuitApp_Button(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();

        }

        private void RandomTournament_Click(object sender, RoutedEventArgs e)
        {
            {
                Random rnd = new Random();
                int kisiSayisi = PlayerList.Items.Count;
                for (int i = 1; i <= kisiSayisi; i++)
                {
                    int tutulan = rnd.Next(0, PlayerList.Items.Count);
                    if (i % 2 == 1)
                    {
                        RandomList1.Items.Add(PlayerList.Items[tutulan]);
                        PlayerList.Items.RemoveAt(tutulan);
                    }
                    else
                    {
                        RandomList2.Items.Add(PlayerList.Items[tutulan]);
                        PlayerList.Items.RemoveAt(tutulan);
                    }
                }
            }
        }
   
        private void RemoveListButton_Click(object sender, RoutedEventArgs e)
        {
            PlayerList.Items.Clear();
        }

        private void CancelTournamentDraw_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

