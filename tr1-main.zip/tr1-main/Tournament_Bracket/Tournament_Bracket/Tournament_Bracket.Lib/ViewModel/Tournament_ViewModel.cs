﻿
namespace Tournament_Bracket.Lib.ViewModel
{
    public class Tournament_ViewModel: BindableBase
    {

    }
}
