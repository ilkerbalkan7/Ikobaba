﻿

namespace Tournament_Bracket.Lib.ViewModel
{
    public class CreateTournamentViewModel :BindableBase
    {

    }
}
