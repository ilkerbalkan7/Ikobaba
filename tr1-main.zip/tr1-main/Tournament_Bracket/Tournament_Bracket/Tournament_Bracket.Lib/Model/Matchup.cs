﻿using System.Collections.Generic;

namespace Tournament_Bracket.Lib.Model
{
    public class Matchup
    {     
        /// The unique identifier for storing in the database.
      
        public int Id { get; set; }

       
        /// The person that will win this matchup.
    
        public string Winner { get; set; }

        
        /// The round that this matchup is currently in.
      
        public int MatchupRound { get; set; }
    }
}