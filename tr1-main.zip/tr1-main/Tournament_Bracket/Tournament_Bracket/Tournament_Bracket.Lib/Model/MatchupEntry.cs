﻿
namespace Tournament_Bracket.Lib.Model
{
    public class MatchupEntry
    {
        /// The unique identifier that will be given by the database.
        public int Id { get; set; }

        /// The team that will be entering a matchup.
        public Player PlayersCompeting { get; set; }

        /// The score of the match when the matchup entry is done.  
        public int Score { get; set; }
    }

}


