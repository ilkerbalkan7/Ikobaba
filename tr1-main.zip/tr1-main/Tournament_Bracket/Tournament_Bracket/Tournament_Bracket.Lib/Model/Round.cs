﻿
using System.Collections.Generic;


namespace Tournament_Bracket.Lib.Model
{
    public class Round
    {
        public int Id { get; set; }

        public int RoundNumber { get; set; }

        public IEnumerable<Matchup> Matchups { get; set; }
    }
}