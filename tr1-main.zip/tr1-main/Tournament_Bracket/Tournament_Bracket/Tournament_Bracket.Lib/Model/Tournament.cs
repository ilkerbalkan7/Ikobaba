﻿
using System.Collections.Generic;


namespace Tournament_Bracket.Lib.Model
{
    public class Tournament
    {
        public int Id { get; set; }

        public string TournamentName { get; set; }

        public decimal EntryFee { get; set; }

        public IEnumerable<Player> EnteredPlayers { get; set; }

        public IEnumerable<IEnumerable<Matchup>> Rounds { get; set; }

    }
}